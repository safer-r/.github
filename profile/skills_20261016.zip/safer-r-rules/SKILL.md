---
name: safer-r-rules
description: Migrate, write, or review functions for the safer-r project family (saferDev, saferGG, saferGraph, saferMake, saferMatrix, saferTool, saferTool2) — safer-r backbone structure, the CRAN-ready arg_check() v2.0.0 block, internal-function conventions, migration lessons, and validation commands. Use when working on any safer-r package, converting an R function to safer-r style, or writing arg_check() calls.
---

# When to use

Use this skill when working on any package of the safer-r project family —
migrating functions to the current safer-r standard, writing or reviewing
`arg_check()` calls, converting a function with the safer-r backbone, or
preparing a safer-r package for CRAN submission.

Style basics (qualified namespaces, complete argument lists, mandatory
`{ }`) live in the `r-code-style` skill: apply it together with this one —
this skill does not repeat those three rules.

Current per-package migration status is NOT stored here: read the
`AGENTS.md` at the root of the local safer-r checkout (the parent folder of
the package repositories) for the up-to-date state.

# Why safer-r exists: the features a safer-R function guarantees

R is a permissive language that "tries to work" in many situations and
returns something where other languages would error
(see <https://github.com/safer-r>). The problems targeted: non-intuitive
behaviors (`sample(8, size = 2)` silently sampling from `1:8`,
`all(NA, na.rm = TRUE)` returning `TRUE`, `all()` returning `TRUE` when
empty, typos like `na.rn =` or `colapse =` being silently swallowed by
`...`), weak control of same-name objects in the R scope (a user-redefined
`mean()`, the dplyr/plyr `summarize()` masking where the result depends on
the package import order), and error messages that do not name the
embedding function. Functions of class S3 from the safer-R project all
present the same encoding structure before the 'main' code section — the
backbone — which tackles these aspects:

- Accuracy
    - Package systematically indicated for any used function (R scope
      seeking controlled). Example `base::paste()` instead of `paste()`.
    - All the arguments of functions written, even if default values are
      used, to prevent argument name change or default value change (like
      the `stringsAsFactors` argument of `read.table()`, for which the
      default value changed from `TRUE` to `FALSE` since R version 4.0).
      Example `base::sum(1:3, na.rm = FALSE)` instead of `base::sum(1:3)`.
    - Argument `safer_check` added in each safer-R function, that checks
      1) the presence in local R library folders of all the non basic
      packages and functions used in the code (`ggplot2::geom_bar` for
      instance) and 2) that all the classical R operators (`<-`, `(`, etc.)
      are not overwritten by other imported packages, since these packages
      always precede the base R items in the R scope.
    - Argument `lib_path` added in each safer-R function, to deal with the
      default paths of R libraries or to set specific paths.
    - Strong checking of each argument (the `arg_check()` block, below), for
      instance: values for arguments with no default values; expected
      class, type, mode, length, restricted values panel, kind of numeric
      values in addition to the integer/double distinction (proportion
      only? Inf values authorized? negative values authorized?); authorized
      `NA` (among other values, never as unique value) or not; authorized
      `NULL` value or not; authorized empty value or not (empty list for
      instance); authorized `""` value in vectors of characters or not;
      expected structure of complex objects, like data frames and lists.
    - Seeding of the random number generator using an argument each time
      randomness is used inside the safer-r function, and protecting
      potential seeding in the global environment, by returning to this
      seeding when the safer-r function execution ends.
    - Checking that all graphics devices opened by a safer-r function are
      closed (optional) and that the graphic parameters return to the
      settings applied before the safer-r execution.
    - Curly brackets systematically written.
- Intuitiveness
    - Argument `...` not authorized in safer-R functions.
    - Argument with `NA` as only value not authorized in safer-R functions,
      in order to deal with `if(all(X, na.rm = TRUE)){}` that would return
      `TRUE` if `X` is only made of `NA`.
- Explicit messages
    - Name of the functions and corresponding packages in all error and
      warning messages, including the embedding functions, so that we
      better know the origin of the message.
    - Explicit error messages.
    - All warning messages added in the error message string.

# The safer-r backbone (what a converted function looks like)

The authoritative template is `backbone_<VERSION>.R` (currently
`backbone_v20.0.R`) in the `inst/` folder of the local `saferMake`
repository — reference copy; in saferMake itself the backbone is
hard-coded in `.build_rebuilt()` (see saferMake's own `AGENTS.md`). It is a
template with placeholder `if()` blocks: it does not parse standalone —
never `parse()` it as a validation step. Every safer-r function follows this
skeleton:

1. roxygen header (`@title`, `@description`, `@param`, `@returns`,
   examples prefixed with the "Warning: these examples may not work well..."
   comment).
2. `# DEBUGGING` block: commented-out assignments of every argument, plus
   commented `function_name`, `arg_user_setting`, `arg_names` lines.
3. `#### package name` → `package_name <- "<pkg>"` (write `NULL` if the
   function is not in a package).
4. `#### internal error report link` → GitHub issues URL of the package
   (shown in internal-error messages; `NULL` if no link to propose).
5. `#### function name` → the function name (with `()`) recovered through
   `base::match.call(definition = , call = , expand.dots = FALSE, envir = )`
   on `sys.parent(n = 0)` frames (`n = 0` deliberately, so that a safer-r
   function inside another function still works); a `pkg::fun()` call is
   reduced to `fun()`.
6. `#### arguments settings` → `arg_user_setting` (user-provided arguments
   only; always a list, even with 0 or 1 argument — hence `lapply()` usage),
   `arg_user_setting_eval` (unevaluated values resolved through
   `base::get(x = , pos = -1L, envir = base::parent.frame(n = 2), mode = "any", inherits = TRUE)`,
   `n = 2` because of the `lapply()` closure), and `arg_names` (names of all
   the formals).
7. `#### error_text initiation` → `error_text` flattened to a single string
   (NULL or empty become `""`, no need to check further);
   `error_text_start` = `"ERROR IN "` + package-qualified function name +
   user `error_text` (the `"ERROR IN "` prefix must not be changed, it is
   used for text replacement); internal-error texts
   (`intern_error_text_start`, `intern_error_text_end` carrying the report
   link); and `embed_error_text`, built by replacing `"^ERROR IN "` with
   `" INSIDE "` and stripping the trailing `\n` — use it in the
   `error_text` of safer-r functions called inside the main code, so the
   message names the embedding functions.
8. `#### argument primary checking`:
   - `...` forbidden (developer code-writing control, `# nocov`-marked);
   - mandatory args of safer-r functions present: `lib_path`,
     `safer_check`, `error_text` for public functions; `lib_path`,
     `error_text` for internal `intern_.` functions; `error_text` for
     `.base_op_check` itself;
   - arguments with no default value actually provided (per-function
     `no_def_args` vector + `base::missing()` check — optional section);
   - management of NULL arguments (per-function `tempo_arg` vector;
     arguments allowed to be NULL — `seed`, `lib_path`, `error_text` — are
     inactivated in it);
   - management of empty non NULL arguments;
   - management of NA arguments: an argument made of `NA` only is ALWAYS
     forbidden (mandatory section, and before any `all(, na.rm = TRUE)`
     usage, since `all(NA, na.rm = TRUE)` returns `TRUE`).
9. `#### environment checking`:
   - `safer_check` value checked (must be a single logical value, `TRUE` or
     `FALSE` only);
   - check of lib_path — ALWAYS executed, never guarded by `safer_check`:
     trailing `/` or `\` stripped (`base::.libPaths()` does not support
     them), `.libPaths()` updated and restored via `on.exit()`;
     `base::.libPaths(new = , include.site = TRUE)` with an empty `new` is
     the idiom to just query paths;
   - check of the required functions from the required packages, under
     `safer_check == TRUE`, via
     `utils::getFromNamespace(x = ".pack_and_function_check", ns = "<pkg>", pos = , envir = )`
     then
     `.pack_and_function_check(fun = ..., lib_path = ..., error_text = embed_error_text)`
     — each required function written preceded by its package name
     (`"ggplot2::geom_bar"` for instance), internal ones as
     `"saferDev:::.base_op_check"`;
   - `# escaping CRAN submission NOTE for internal functions`:
     `.base_op_check <- utils::getFromNamespace(x = ".base_op_check", ns = "<pkg>", pos = , envir = )`
     — internal functions must be fetched this way, NOT called as
     `<pkg>:::fun()`, to avoid the CRAN NOTE about `:::` usage (not
     mandatory if the function is not designed for CRAN submission);
   - critical operator checking via
     `.base_op_check(error_text = embed_error_text)`, under
     `safer_check == TRUE`.
10. `#### argument secondary checking` — the `arg_check()` block (below),
    followed by `management of "" in arguments of mode character`
    (optional section: the character arguments listed there cannot contain
    `""`).
11. `#### second round of checking and data preparation`:
    - code that protects `set.seed()` in the global environment (optional
      section, removed if the function has no `seed` argument): the
      `.Random.seed` of `.GlobalEnv` is saved and restored via
      `on.exit()` — seeding always acts at the `.GlobalEnv` level,
      wherever it is applied; if no `.Random.seed` exists yet, seeding is
      inactivated on exit (return to complete randomness);
    - warning initiation: `ini_warning_length <- base::options()$warning.length`,
      `base::options(warning.length = 8170)`, `warn <- NULL`,
      `warn_count <- 0` — warnings are accumulated in `warn` (numbered by
      `warn_count`) instead of being emitted immediately;
    - graphic device checking (optional section, removed if no graphics):
      devices opened by the function must be closed before end of
      execution (`dev_list` compared to `grDevices::dev.list()` in an
      `on.exit()`, `# nocov`-marked internal control), and the
      `graphics::par()` settings are restored on exit;
    - other checkings (optional, user-specific).
12. `#### main code`, with `# nocov` markers on unreachable/internal-error
    lines (coverage expectation is 100%), plus the template blocks:
    - warning accumulation: `warn_count <- warn_count + 1`, message
      appended to `warn`;
    - error message block: `base::stop()` with `error_text_start`;
    - error message block when warning sections are present: the error
      string also carries all the accumulated warnings
      (`"IN ADDITION\nWARNING(S):..."`) — all warning messages are added
      to the error message string.
13. `#### warning output` — the accumulated `warn` is emitted via
    `on.exit()` with the `"ERROR IN "` prefix replaced by `"FROM "` (only
    when not NULL), then `warning.length` is restored.
14. `#### output` (the returned value, e.g. `base::return(output)`) and
    `#### end of function`.

The `pos = , envir = ` empty arguments in `utils::getFromNamespace()` calls
are deliberate: write every argument, even the empty ones.

# The `arg_check()` block — v2.0.0 semantics (the heart of the migration)

Since `saferDev` 2.0.0, `class`, `typeof` and `mode` are compared EXACTLY
(element per element, same values, same order) to `class(data)`,
`typeof(data)`, `mode(data)`:

- `class = "matrix"` always fails on R >= 4.0.0 (a matrix is
  `c("matrix", "array")`). Write `class = c("matrix", "array")`.
- Ordered factors are `c("ordered", "factor")`.
- `class = "vector"` is NO LONGER a shortcut for the numeric/integer/
  character/logical/complex/expression classes. Write the exact class, or
  `class = NULL`.
- `typeof()` and `mode()` each return a single string: a vector of length
  > 1 in the `typeof` or `mode` argument always reports a problem.
- R-version-dependent class values: use SEVERAL `arg_check()` calls
  (`tempo1`, `tempo2`, ...) and a single combined `if(any(...problem...))`
  stop, sharing `arg_check_error_text` (built as
  `paste0("ERROR ", embed_error_text, "\n\n")`).
- `double_as_integer_allowed = TRUE` also rescues `class = "integer"` when
  the object is a double with zero modulo (such objects have class
  `"numeric"`).
- Numeric-value features of the check: `prop = TRUE` restricts to
  proportions (values in [0, 1]), `neg_values = FALSE` forbids negative
  values, `inf_values = FALSE` forbids `Inf` values, and
  `double_as_integer_allowed` handles the integer/double distinction.
- `na_contain = TRUE` authorizes `NA` among other values (an argument made
  of `NA` only is ALWAYS forbidden anyway, by the backbone primary
  checking).
- Arguments allowed to be NULL are checked inside
  `if( ! base::is.null(x = seed)){...}` rather than by `arg_check()`.

## Canonical single-argument call (copy this exact shape)

```
tempo <- saferDev::arg_check(data = <arg>, class = NULL, typeof = NULL, mode = NULL, length = NULL, prop = FALSE, options = NULL, double_as_integer_allowed = FALSE, all_options_in_data = FALSE, na_contain = FALSE, neg_values = TRUE, inf_values = TRUE, print = FALSE, data_name = NULL, data_arg = TRUE, safer_check = FALSE, lib_path = lib_path, error_text = embed_error_text) ; base::eval(expr = ee, envir = base::environment(fun = NULL), enclos = base::environment(fun = NULL))
```

EVERY argument is written explicitly, even at its default. `safer_check =
FALSE` inside other safer-r functions (avoids repeated checking that would
exponentially increase the execution time). `error_text = embed_error_text`
normally; when several `arg_check()` calls target the SAME argument, the
LAST call of the group uses `error_text = arg_check_error_text` so that
only one combined message is printed.

## Block scaffolding (always present)

```
argum_check <- NULL
text_check <- NULL
checked_arg_names <- NULL # for function debugging: used by r_debugging_tools
arg_check_error_text <- base::paste0("ERROR ", embed_error_text, "\n\n", collapse = NULL, recycle0 = FALSE)
ee <- base::expression(argum_check <- base::c(argum_check, tempo$problem) , text_check <- base::c(text_check, tempo$text) , checked_arg_names <- base::c(checked_arg_names, tempo$object.name))
# ... one tempo <- arg_check(...) line per argument ...
if( ! base::is.null(x = argum_check)){
    if(base::any(argum_check, na.rm = TRUE)){
        base::stop(base::paste0("\n\n================\n\n", base::paste0(text_check[argum_check], collapse = "\n\n", recycle0 = FALSE), "\n\n================\n\n", collapse = NULL, recycle0 = FALSE), call. = FALSE, domain = NULL)
    }
}
```

# Migration lessons learned the hard way (do not repeat)

- **Mixed-quote strings break `all_args_here()`**: never write a string like
  `paste0(x, ': "', ...)` (single quote opening, double quote inside). The
  in-quotes replacement of saferDev misparses it, blanks `(` inside what it
  wrongly considers a string, and `.fun_args_pos()` then raises
  `INTERNAL ERROR 3` (closing bracket not detected). The compliant form is
  `paste0(x, ": \"", ...)` (escaped double quote), as in saferDev itself.
  This bug was present in the backbone copies of saferGraph/post_plot.R,
  saferGG/gg_box.R, gg_empty.R and saferTool/df_remod.R (fixed 2026-10-14).
- Do not write BOTH `class = "logical"` AND `typeof = "logical"` (or
  `class = "character"` with `typeof = "character"`) redundantly: set only
  ONE of `class`/`typeof`/`mode` to describe a simple type, leave the
  others `NULL`. For a plain logical/character argument, the preferred form
  is `class = NULL, typeof = "<type>", mode = NULL`. (This exact redundancy
  was introduced by an AI pass and had to be fixed afterwards.)
- Do not "modernize" old `class = "vector"` calls by guessing a replacement
  class: choose the exact class the argument must have, or use
  `typeof`/`mode` only, or use the multiple-`tempo` pattern for
  version-dependent classes.
- Do not modify the `ee <- base::expression(...)` scaffolding, the
  `base::eval(expr = ee, envir = base::environment(fun = NULL), enclos = base::environment(fun = NULL))`
  idiom, or the `parent.frame(n = 2)` / `parent.frame(n = 3)` comments: the
  frame arithmetic is subtle and documented in-place (sapply calls lapply
  internally, hence n = 3 in some blocks).
- Do not guard the backbone lib_path check behind `safer_check`: lib_path is
  always checked/processed.
- Remove the optional backbone sections that do not apply (no-def-args,
  seed, graphic devices, `""` checks) rather than leaving them inactivated.
- Inside `saferDev` itself, a few functions cannot use `arg_check()` on
  their own arguments (chicken-and-egg, e.g. `intern_.pack_and_function_check.R`):
  they keep manual checks — do not force `arg_check()` there.
- `# nocov` markers keep internal-error branches out of coverage; the
  mandatory-formals block IS covered by a dedicated test file that builds a
  function with a mandatory formal removed (see
  `tests/testthat/test-mandatory_args.R` in saferDev) — replicate that test
  pattern in migrated packages.

# Conventions

- Internal functions: file `R/intern_.<name>.R`, function `.name()`, accessed
  inside the package via `utils::getFromNamespace()`, from other packages
  via `<pkg>:::name()` only.
- Exported functions carry `safer_check`, `lib_path`, `error_text`.
- `dev/` is tracked development scratch (excluded from the build via
  `^dev$` in `.Rbuildignore`); commit its changes like any other file.
- Documentation regenerated with `devtools::document()` (roxygen2 8.0.0);
  never hand-edit `man/` or `NAMESPACE`.
- CI: `rworkflows` GitHub action (ubuntu/macOS/windows matrix). Exact-match
  `class = c("matrix", "array")` and `double_as_integer_allowed` semantics
  exist precisely to avoid cross-platform (R-version) CI failures.

# Validation

Per package, from the package directory:

```
Rscript -e "setwd('<pkg dir>'); pkgload::load_all(path = '.', quiet = TRUE); res <- testthat::test_dir('tests/testthat', reporter = 'summary'); quit(save = 'no', status = if(length(res) == 0 || any(sapply(res, function(x) x$failed) > 0)) 1 else 0)"
```

plus `R CMD check` before any CRAN submission. Migration order: edit `R/`
first, then `devtools::document()`, then rebuild the package.

Note on the testthat summary reporter: its result objects expose `failed`/`passed`
as data frames, not integers — prefer the `silent` reporter and
`base::as.data.frame(x = res)` / `base::table(x = s$failure_type)` to count,
or read failures from the `result` list column messages.

# Writing and testing safer-r functions (tests + 100% coverage)

## Test file style (saferDev reference)

- One `tests/testthat/test-<function>.R` per function, starting with
  `testthat::test_that("<function>()", {`.
- Sections in order: `## data argument values` (small deterministic fixtures,
  int1/str1/mat1...), `## initialization of tests` (expect_error/expect_no_error
  probes), then `## tests (ordered by arg appearance and conditions in the
  code)` with one `######## <backbone block name>` header per backbone block
  mirrored from the R file, then `## end tests`, `## other tests`,
  and `base::rm(list = base::ls())` before closing `}` to avoid a CRAN warning.
- Every call in tests is fully qualified with ALL formals written
  (`saferDev::env_check(pos = int1, name = str1, safer_check = TRUE, lib_path = NULL, error_text = "")`),
  errors probed with `testthat::expect_error(...)` (optionally capturing the
  message), success with `testthat::expect_no_error(...)`, values with
  `testthat::expect_equal(object = ..., expected = ...)`.
- Tests run via `tests/testthat.R` (standard `library(testthat);
  library(<pkg>); test_check("<pkg>")`).
- Call functions through `saferDev::<fun>()` or `<pkg>:::<internal>()` so the
  tests exercise the qualified calls exactly as users would.

## The mandatory-args block test (`test-mandatory_args.R`)

The `######## mandatory arg of safer-r functions` block cannot be triggered by
user values (it only fires when the function is WRITTEN without a mandatory
formal). Cover it with a dedicated test file that rebuilds each function with
the mandatory formal removed from `formals()`:

```r
for(fn in base::names(x = full_calls)){
    f <- base::get(x = fn, envir = base::asNamespace("<pkg>"))
    fml <- base::formals(fun = f)
    fml_dropped <- fml[base::setdiff(x = base::names(x = fml), y = "lib_path")]
    tempo_env <- base::new.env(parent = base::environment(fun = f))
    tempo_env[[fn]] <- base::as.function(base::c(fml_dropped, base::list(base::body(f))), envir = tempo_env)
    cl <- full_calls[[fn]]
    res <- base::tryCatch(
        expr = base::eval(expr = cl, envir = tempo_env),
        error = function(e){base::conditionMessage(e)}
    )
    testthat::expect_true(object = base::grepl(x = res, pattern = "FOLLOWING ARGUMENT IS MANDATORY IN SAFER-R FUNCTIONS:", fixed = TRUE), label = base::paste0(fn, ": mandatory-args block message"))
    testthat::expect_true(object = base::grepl(x = res, pattern = "lib_path", fixed = TRUE), label = base::paste0(fn, ": lib_path reported as missing mandatory arg"))
    testthat::expect_false(object = base::grepl(x = res, pattern = "object '", fixed = TRUE), label = base::paste0(fn, ": no error before the mandatory-args block"))
}
```

- Public functions: drop `lib_path` (message says the mandatory args are
  `lib_path`, `safer_check`, `error_text`; `lib_path` is reported first).
  Each call in `full_calls` must pass every remaining formal explicitly.
- Internal functions (`intern_.`/`.name()`): same with their `lib_path`.
- `.base_op_check()` special case: drop `error_text` but pre-define
  `error_text <- ""` in `tempo_env` (it is used before the block fires);
  rebuild the function with zero formals:
  `base::as.function(base::c(base::formals(fun = f)[base::character()], base::list(base::body(f))), envir = tempo_env)`.
- No `# nocov` markers are needed for this block: the tests execute it.
- `tests/testthat/test-mandatory_args.R` carries no R source modifications.

## 100% coverage workflow

1. Write the per-function test files so every branch of the main code is hit.
2. Mark truly unreachable lines (internal-error handlers, defensive branches
   that cannot be triggered by user values) with:
   `# nocov start` ... `# nocov end` (single lines: trailing `# nocov`).
   Keep these minimal — every removable one is a lost branch.
3. Run coverage and require 100%:

```
Rscript -e "pkgload::load_all(path = '.', quiet = TRUE); cov <- covr::package_coverage(path = '.', quiet = FALSE); base::print(x = covr::percent_coverage(x = cov)); base::print(x = covr::zero_coverage(x = cov))"
```

4. Iterate: for every zero-coverage line, either add a test that triggers it or
   justify/mark it `# nocov`. Do not lower the expectation.
5. CI publishes coverage with codecov (`run_covr: true` +
   `CODECOV_TOKEN` in `rworkflows.yml`); the local `covr` run above must show
   100% before pushing.

## Test-file hygiene when migrating an old package

- First list the orphaned test files: `test-<fn>.R` whose `<fn>.R` no longer
  exists in `R/` (functions removed in earlier cleanups). Delete them — they
  fail noisily and mask real regressions.
- Old-era tests call functions without the mandatory formals or with renamed
  arguments; rewrite them in the saferDev style rather than patching calls.

# References

- safer-r profile: <https://github.com/safer-r>
- Backbone reference copy: `inst/backbone_<VERSION>.R` (currently v20.0) of
  the local saferMake repository; saferMake's own `AGENTS.md` for the
  converter app internals.
- Per-package migration status: the `AGENTS.md` at the root of the local
  safer-r checkout.
