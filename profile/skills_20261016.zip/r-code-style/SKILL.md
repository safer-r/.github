---
name: r-code-style
description: Write R code with fully qualified namespaces, complete argument lists, and mandatory curly brackets — every function call must use package::fun(...) or package:::fun(...), name every argument explicitly (including default values), and every function body, if/else, for/while/repeat block must use { }, never one-line bodies, unless a project AGENTS.md overrides this. Use when writing or reviewing R code.
---

# When to use

Use this skill when writing or reviewing any R code: new functions, scripts,
tests, emitted/generated R, or a single call added to a `.R` file.

Project-level `AGENTS.md` instructions always win over this skill when the two
conflict.

# The three core rules

1. Every function call is written with its package: `package::fun(...)`.
   `package:::fun(...)` only for non-exported (internal) functions.
   Never a bare function name.
2. Every argument of the call is written explicitly and named, even when the
   value used is the default.
3. **Every block is written with curly brackets `{ }`, always.** This applies to
   function bodies, `if`, `else`, `for`, `while`, `repeat` — even for
   single-statement bodies. Never write a one-line block without `{ }`. Never.
   Never ever.

Rationale (from the safer-R project): bare names let another package or a
user-defined function silently mask the intended function, and omitted
arguments silently adopt whatever default the installed R version has — both
change results without any warning (e.g. `read.table()`'s `stringsAsFactors`
default flipped in R 4.0; a typo like `sum(1, 2, na.rn = TRUE)` is swallowed by
`...`). Writing the package and every argument makes the code robust to
package-loading order, masking, and default-value drift across R versions.

```r
# Wrong
x <- paste0("a", "b")
total <- sum(1:3)

# Right — paste0(..., collapse = NULL, recycle0 = FALSE) and sum(..., na.rm = FALSE)
x <- base::paste0("a", "b", collapse = NULL, recycle0 = FALSE)
total <- base::sum(1, 2, 3, na.rm = FALSE)
```

```r
# Wrong
base::grepl(x = txt, pattern = "error")

# Right — grepl(pattern, x, ignore.case, perl, fixed, useBytes), all six written
found <- base::grepl(
    pattern = "error",
    x = txt,
    ignore.case = FALSE,
    perl = FALSE,
    fixed = FALSE,
    useBytes = FALSE
)
```

```r
# Wrong
base::ifelse(test = ok, "yes")

# Right — ifelse(test, yes, no), exactly three arguments
label <- base::ifelse(test = ok, yes = "yes", no = "no")
```

```r
# Wrong
base::stop("something failed")

# Right — stop(..., call. = TRUE, domain = NULL); call. = FALSE chosen deliberately
# so the error is reported without the call itself (call. = TRUE is the default)
base::stop("something failed", call. = FALSE, domain = NULL)
```

# Mandatory curly brackets — always, without exception

Every block uses curly brackets `{ }`: function bodies, `if`, `else`, `for`,
`while`, `repeat`. This holds even for single-statement bodies. Never write a
one-line block without `{ }`. Never. Never ever.

Rationale: a braceless block is a classic silent-bug source — adding a second
statement later silently leaves the first one outside the block, and R's `else`
placement rules make braceless `if/else` fragile inside functions. Braces make
block boundaries explicit and reviewable.

```r
# Wrong — braceless if
if(ok)
    base::print(x = "fine")

# Right
if(ok == TRUE){
    base::print(x = "fine")
}
```

```r
# Wrong — braceless single-statement function body
fun1 <- function(x)
    base::sum(x = x, na.rm = FALSE)

# Right
fun1 <- function(x){
    base::sum(x = x, na.rm = FALSE)
}
```

```r
# Wrong — braceless loop
for(i in 1:3)
    base::print(x = i)

# Right
for(i in 1:3){
    base::print(x = i)
}
```

This applies equally when writing code inline in conversations, in helper
scripts, in generated code, and in one-off R snippets passed to `Rscript -e`.

# How to get the argument list right

Never invent an argument list from memory: signatures change between R
versions, which is precisely what this style defends against. Before writing a
call, look up the exact signature and defaults, then write every argument:

```r
# Light check — named arguments only
base::print(x = base::args(name = base::paste0))

# Full check — names and default values; formals(fun, envir)
base::formals(fun = base::paste0, envir = base::environment(fun = base::paste0))
```

If R is not available in the session, read the function's help page (online
reference manual or websearch) instead of guessing.

# Details and edge cases

## `...` arguments

Functions with `...` take their main values in the `...` slots: write those
values first, positionally, then write every named argument explicitly. Never
write a literal `...` in a call — at evaluation time R rejects it with the
error `'...' used in an incorrect context` (it parses, but does not run).

```r
# Right — paste0's user values fill ..., then the named arguments follow
msg <- base::paste0("ERROR ", code, "\n\n", collapse = NULL, recycle0 = FALSE)

# Right — c() has only ..., so there are no named arguments to add
mandat_args <- base::c("lib_path", "safer_check", "error_text")

# Right — unlist(x, recursive = TRUE, use.names = TRUE)
flat <- base::unlist(x = error_text, recursive = TRUE, use.names = TRUE)
```

When defining a new function, avoid `...` unless pass-through is the whole
point of the function: it swallows argument typos and partial matches
silently. (safer-r functions forbid `...` entirely.)

## Functions of the package being developed

Qualify those too, with the package's own name, so the code survives a stale
loaded copy or masking (note: all arguments written, exactly as for any other
function):

```r
# Inside the saferDev package, calling its own exported function:
res <- saferDev::is_package_here(req_package = "ggplot2", safer_check = TRUE, lib_path = NULL, error_text = "")
```

## Functions passed as objects

When a function is passed as a value (e.g. `FUN =`), pass the qualified
object; the calls made internally by the host function are not code you write:

```r
out <- base::lapply(X = x, FUN = base::mean)
```

## Syntax that is not a function call

Infix operators (`+`, `==`, `%in%`, `|`, etc.) and language constructs
(`{`, `(`, `[`, `[[`, `$`, `<-`, `if`/`else`, `for`, `while`, `function`) are
treated as operators and syntax, not function calls to qualify (even though
they parse as calls to primitive functions such as `` base::`[` ``). Every
function call *inside* them still does:

```r
tempo_log <- ! mandat_args %in% arg_names # %in% is an operator: no qualification
if (base::any(x = tempo_log, na.rm = TRUE)) { # any(...) is a call: qualified, complete
    base::stop("missing arguments", call. = FALSE, domain = NULL)
}
```

# Verification

After writing or editing R code:

1. every function call is `pkg::fun(...)` / `pkg:::fun(...)`;
2. every argument is present, named, and matches the signature you looked up;
3. **mandatory curly brackets**: run the parser-based checker (exact, no
   false positives) and fix any finding before finalizing:

   ```
   Rscript <this skill folder>/brace_check.R                 # scans the safer-r packages
   Rscript <this skill folder>/brace_check.R <file-or-dir>   # scans any file / directory
   ```

   It reports every `if` / `else` / `for` / `while` / `repeat` body and
   function body whose first token is not `{` (else-if chains are allowed,
   since the chained `if` is itself checked). Exit status 0 = clean, 1 =
   findings (details printed + written to `%TEMP%\opencode\brace_findings.csv`).
   It flagged 165 braceless blocks across the safer-r packages in 2026-10
   (all fixed); keep it at 0 going forward.
4. the code parses and runs, e.g.
   `base::parse(text = code, file = "", n = NULL, prompt = "?", keep.source = base::getOption(x = "keep.source", default = NULL), srcfile = NULL, encoding = "unknown")`,
   or the project's own checks such as `devtools::test()` or `R CMD check`
   (named there, not code you write — use their documented invocation as-is).

# References

- Philosophy and rationale: the safer-R profile README,
  <https://github.com/safer-r/.github/blob/main/profile/README.md> ("Features
  of the safer-R functions" states the qualification and argument-completion
  rules; the mandatory `{ }` rule is the safer-r project's own convention).
- Canonical worked example of this style: `inst/backbone_v19.6.R` in the
  saferMake repository (local copy:
  `C:\Users\gmillot\Documents\Git_projects\safer-r\saferMake\inst\backbone_v19.6.R`).
  Note the profile repo's README links a `backbone.R` that is not present there;
  the saferMake copy is the reference.
- When writing a full safer-r function (with `lib_path`, `safer_check`,
  `error_text` and the checking backbone), follow the saferMake project's own
  `AGENTS.md` rather than this general skill.
