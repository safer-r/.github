# brace_check.R — detect missing curly brackets in R files
#
# Detects every if / else / for / while / repeat body and function body that is
# not wrapped in { }. Uses R's own parser (base::getParseData), so it is exact
# (no text-matching false positives): if / else / for / while / repeat /
# function are keyword tokens, and a body is compliant when its first terminal
# token is '{' (else-if chains are allowed without their own braces).
#
# Usage:
#   Rscript brace_check.R                       # scan the safer-r packages
#   Rscript brace_check.R path1 path2 ...       # scan files or directories
#
# Output: a table package/file/function/line/kind, and a CSV next to the
# script (or in the output dir of the last path) when findings exist.
# Exit status 0 = clean, 1 = findings found, 2 = usage/parse error.

base::options(keep.source = TRUE)

scan_one_file <- function(pkg_label, f){
  findings <- base::list()
  lines <- base::readLines(f, warn = FALSE)
  src <- base::paste(lines, collapse = "\n")
  p <- base::tryCatch(base::parse(text = src), error = function(e){
    findings[[base::length(findings) + 1]] <<- base::data.frame(package = pkg_label,
      file = f, function_name = NA_character_, line = NA_integer_,
      kind = "PARSE ERROR", code = base::conditionMessage(e), stringsAsFactors = FALSE)
    NULL
  })
  if(base::is.null(p)) return(findings)
  pd <- utils::getParseData(p)
  if(base::is.null(pd) || base::nrow(pd) == 0) return(findings)
  pd <- pd[base::order(pd$line1, pd$col1), ]
  row_of <- function(id) base::match(id, pd$id)
  pos <- function(r) r$line1 * 100000L + r$col1

  first_term <- function(r){
    s <- pos(r) ; e <- r$line2 * 100000L + r$col2
    toks <- pd[pd$terminal == TRUE & pd$token != "COMMENT" &
      (pd$line1 * 100000L + pd$col1) >= s & (pd$line2 * 100000L + pd$col2) <= e, ]
    toks <- toks[base::order(toks$line1, toks$col1), ]
    if(base::nrow(toks) == 0) NULL else toks[1, ]
  }

  # enclosing function name for reporting (innermost `name <- function` span)
  fn_rows <- base::which(pd$token == "FUNCTION")
  fn_spans <- base::data.frame(start = base::integer(), end = base::integer(),
    name = base::character(), stringsAsFactors = FALSE)
  for(fr in fn_rows){
    r_fn <- pd[fr, ]
    r_expr <- pd[base::match(r_fn$parent, pd$id), ]
    if(base::nrow(r_expr) != 1) next
    par_row <- pd[base::match(r_expr$parent, pd$id), ]
    name <- NA_character_
    if(base::nrow(par_row) == 1){
      kids <- pd[pd$parent == par_row$id, ]
      asg_rows <- base::which(kids$token %in% base::c("LEFT_ASSIGN", "EQ_ASSIGN", "RIGHT_ASSIGN"))
      if(base::length(asg_rows) > 0){
        a_row <- kids[kids$id == base::min(kids$id[asg_rows]), ]
        before <- kids[pos(kids) < pos(a_row) & kids$token == "expr", ]
        before <- before[base::order(pos(before)), ]
        after <- kids[pos(kids) > pos(a_row) & kids$token == "expr", ]
        if(base::nrow(after) > 0 && base::max(pos(after)) == pos(r_expr) && base::nrow(before) > 0){
          bt <- before[base::nrow(before), ]
          btk <- pd[pd$parent == bt$id & pd$terminal == TRUE, ]
          btk <- btk[btk$token %in% base::c("SYMBOL", "SYMBOL_FUNCTION_CALL", "STR_CONST"), ]
          if(base::nrow(btk) > 0) name <- btk$text[base::nrow(btk)]
        }
      }
    }
    fn_spans <- base::rbind(fn_spans, base::data.frame(start = pos(r_expr),
      end = r_expr$line2 * 100000L + r_expr$col2, name = name, stringsAsFactors = FALSE))
  }
  name_for_line <- function(ln){
    pp <- ln * 100000L + 1L
    hits <- fn_spans[fn_spans$start <= pp & fn_spans$end >= pp, ]
    if(base::nrow(hits) == 0) return(NA_character_)
    hits <- hits[base::order(hits$end - hits$start), ]
    named <- hits[!base::is.na(hits$name), ]
    if(base::nrow(named) > 0) named$name[1] else NA_character_
  }

  match_paren <- function(lp_row){
    depth <- 0
    for(j in lp_row:base::nrow(pd)){
      if(pd$token[j] == "'('"){ depth <- depth + 1 }
      else if(pd$token[j] == "')'"){ depth <- depth - 1 ; if(depth == 0) return(j) }
    }
    NA_integer_
  }

  flag <- function(kind, fname, kw_line){
    findings[[base::length(findings) + 1]] <<- base::data.frame(package = pkg_label,
      file = f, function_name = fname, line = kw_line, kind = kind,
      code = base::trimws(lines[kw_line]), stringsAsFactors = FALSE)
    base::invisible(NULL)
  }
  kw_rows <- base::which(pd$token %in% base::c("IF", "FOR", "WHILE", "REPEAT", "FUNCTION"))
  for(kid in kw_rows){
    kw <- pd$token[kid]
    kw_line <- pd$line1[kid]
    fname <- name_for_line(kw_line)
    if(kw == "REPEAT"){
      body_node <- pd[kid + 1, ]
    } else {
      lp <- NA_integer_
      for(j in (kid + 1):base::nrow(pd)){
        if(pd$token[j] == "'('"){ lp <- j ; break }
      }
      if(base::is.na(lp)) next
      rp <- match_paren(lp)
      if(base::is.na(rp) || rp >= base::nrow(pd)) next
      body_node <- pd[rp + 1, ]
    }
    ft <- first_term(body_node)
    braced <- !base::is.null(ft) && ft$token == "'{'"
    kind <- base::switch(kw, IF = "if body", FOR = "for body", WHILE = "while body",
      REPEAT = "repeat body", FUNCTION = "function body")
    if(!braced) flag(kind, fname, kw_line)
    if(kw == "IF"){
      if_expr <- pd[base::match(pd$parent[kid], pd$id), ]
      else_rows <- pd[pd$token == "ELSE" & pd$parent == if_expr$id, ]
      if(base::nrow(else_rows) > 0){
        e_row <- else_rows[base::which.min(else_rows$id), ]
        # else expr = sibling AFTER the ELSE token in source ORDER (positions,
        # not ids: parse-data ids can interleave around the ELSE token)
        else_expr <- pd[pd$parent == if_expr$id &
          (pd$line1 * 100000L + pd$col1) > (e_row$line1 * 100000L + e_row$col1), ]
        else_expr <- else_expr[base::order(else_expr$line1, else_expr$col1), ]
        else_expr <- else_expr[1, ]
        if(base::nrow(else_expr) == 1){
          eft <- first_term(else_expr)
          if(!base::is.null(eft) && eft$token != "IF" && eft$token != "'{'"){
            flag("else body", fname, kw_line)
          }
        }
      }
    }
  }
  findings
}
args <- base::commandArgs(trailingOnly = TRUE)
if(base::length(args) == 0){
  # default: the safer-r package family
  base_dir <- "C:/Users/gmillot/Documents/Git_projects/safer-r"
  targets <- base::list()
  for(pkg in base::c("saferDev", "saferGG", "saferGraph", "saferMake", "saferMatrix",
      "saferTool", "saferTool2")){
    for(sub in base::c("R", base::file.path("inst", "app"),
        base::file.path("tests", "testthat"))){
      d <- base::file.path(base_dir, pkg, sub)
      if(base::dir.exists(d)) targets[[base::length(targets) + 1]] <-
        base::list(dir = d, label = pkg)
    }
  }
} else {
  targets <- base::list()
  for(a in args){
    targets[[base::length(targets) + 1]] <- base::list(dir = a,
      label = base::basename(a))
  }
}

findings <- base::list()
for(t in targets){
  if(base::dir.exists(t$dir)){
    r_files <- base::list.files(path = t$dir, pattern = "\\.[Rr]$",
      full.names = TRUE, ignore.case = TRUE, recursive = FALSE)
    for(f in r_files){
      res <- scan_one_file(t$label, f)
      if(base::length(res) > 0) findings <- base::c(findings, res)
    }
  } else if(base::file.exists(t$dir)){
    res <- scan_one_file(t$label, t$dir)
    if(base::length(res) > 0) findings <- base::c(findings, res)
  }
}

out <- if(base::length(findings) == 0){
  base::data.frame(package = base::character(), file = base::character(),
    function_name = base::character(), line = base::integer(),
    kind = base::character(), code = base::character(), stringsAsFactors = FALSE)
} else {
  o <- base::do.call(base::rbind, findings)
  o[base::order(o$package, o$file, o$line), ]
}
base::cat("missing-brace instances:", base::nrow(out), "\n")
if(base::nrow(out) > 0){
  out_csv <- base::file.path(base::Sys.getenv("TEMP"), "opencode", "brace_findings.csv")
  utils::write.csv(out, out_csv, row.names = FALSE)
  base::cat("full findings written to:", out_csv, "\n")
  base::print(out[, base::c("package", "file", "function_name", "line", "kind")],
    right = FALSE, max = 500)
  base::quit(save = "no", status = 1)
}
base::quit(save = "no", status = 0)
